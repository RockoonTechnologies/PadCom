/*This file is what the .cpp file looks for when it runs*/

#ifndef PadComLib_h
#define PadComLib_h

#include "Arduino.h"

void padStatus(String pstatus);
void com(String custommsg, bool launchperm);
void intialize(bool start);

#endif